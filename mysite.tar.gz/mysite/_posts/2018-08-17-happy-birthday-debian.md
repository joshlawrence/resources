---
title: Happy Birthday Debian!
layout: post
category: linux
---

Wishing the [Debian Project](https://www.debian.org) a very happy birthday this month.  Congratulations on the past 25 years, and here's hoping for 25 more!
