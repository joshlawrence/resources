---
title: Extracting a single table from a MySQL dump
layout: post
category: mysql
---

Tonight I needed to extract the contents of a single table from a mysql dump
file.  The dump file was very large, and I needed to restore this table _very_
quickly.  I found [this
post](http://gtowey.blogspot.com/2009/11/restore-single-table-from-mysqldump.html),
which explains how to do this with sed.

First, locate the start and end line numbers for all tables:

```
# grep -n 'Table structure' dump.sql
19:-- Table structure for table `t1`
40:-- Table structure for table `t2`
61:-- Table structure for table `t3`
```

In this example, we want `t2`.  Now that we have the starting and ending line
numbers for `t2`, we can extract all of the data we need:

`sed -n '40,61 p' dump.sql > t2.sql`

Now restore your sql file and you're good to go.
